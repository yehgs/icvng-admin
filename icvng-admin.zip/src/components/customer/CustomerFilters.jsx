// src/components/customer/CustomerFilters.jsx
import React from 'react';
import { Search, Filter } from 'lucide-react';
import { useAdminTranslation } from "../../hooks/useAdminTranslation.js";

const CustomerFilters = ({ filters, setFilters }) => {
  const { t } = useAdminTranslation();
  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
      <div className="flex items-center gap-2 mb-4">
        <Filter className="h-5 w-5 text-gray-600 dark:text-gray-400" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          {t('customer.filtersHeading')}
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Search */}
        <div className="relative lg:col-span-2">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder={t('customer.searchCustomersPlaceholder')}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={filters.searchTerm}
            onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
          />
        </div>

        {/* Customer Type */}
        <select
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={filters.filterType}
          onChange={(e) => handleFilterChange('filterType', e.target.value)}
        >
          <option value="">{t("orders.allTypes")}</option>
          <option value="BTC">{t('customer.btc')}</option>
          <option value="BTB">{t('customer.btb')}</option>
        </select>

        {/* Customer Mode */}
        <select
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={filters.filterMode}
          onChange={(e) => handleFilterChange('filterMode', e.target.value)}
        >
          <option value="">{t("customer.allModes")}</option>
          <option value="ONLINE">{t("customer.online")}</option>
          <option value="OFFLINE">{t("customer.offline")}</option>
        </select>

        {/* Status */}
        <select
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={filters.filterStatus}
          onChange={(e) => handleFilterChange('filterStatus', e.target.value)}
        >
          <option value="">{t("products.allStatus")}</option>
          <option value="ACTIVE">{t("common.active")}</option>
          <option value="INACTIVE">{t("common.inactive")}</option>
          <option value="SUSPENDED">{t("customer.suspended")}</option>
        </select>
      </div>

      {/* Sort Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            {t('customer.sortByLabel')}
          </label>
          <select
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={filters.sortBy}
            onChange={(e) => handleFilterChange('sortBy', e.target.value)}
          >
            <option value="createdAt">{t("customer.dateCreated")}</option>
            <option value="name">{t('common.name')}</option>
            <option value="email">{t("common.email")}</option>
            <option value="totalOrders">{t("customer.totalOrders")}</option>
            <option value="totalOrderValue">{t("customer.totalValue")}</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            {t('customer.orderLabel')}
          </label>
          <select
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={filters.sortOrder}
            onChange={(e) => handleFilterChange('sortOrder', e.target.value)}
          >
            <option value="desc">{t("customer.descending")}</option>
            <option value="asc">{t("customer.ascending")}</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default CustomerFilters;